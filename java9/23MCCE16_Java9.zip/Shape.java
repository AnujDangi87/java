public abstract class Shape
{
    //getArea abstract class
    public abstract double getArea();

    //Abstract class gerPerimeter
    public abstract double getPerimeter();
}