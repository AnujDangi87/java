public class UnderflowException extends Exception
{
    @Override
    public String toString()
    {
        return "Underflow Exception, Stack is empty!";
    }
}
