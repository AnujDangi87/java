public class KeyNotFound extends Exception
{
    public KeyNotFound()
    {
        
    }
    
    @Override
    public String toString()
    {
        return "Key Not Found!!!!";
    }
}
