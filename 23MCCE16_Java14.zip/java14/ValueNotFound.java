public class ValueNotFound extends Exception
{
    public ValueNotFound()
    {
        
    }
    
    @Override
    public String toString()
    {
        return "Value Not Found!!!!";
    }
}
