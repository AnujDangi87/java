public class EmptyDataStore extends Exception
{
    public EmptyDataStore()
    {
        
    }
    
    @Override
    public String toString()
    {
        return "DataStore is Empty!!!!";
    }
}
