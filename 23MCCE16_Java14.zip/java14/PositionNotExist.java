public class PositionNotExist extends Exception
{
    public PositionNotExist()
    {
        
    }
    
    @Override
    public String toString()
    {
        return "Given Position Does Not Exist!!!!";
    }
}
