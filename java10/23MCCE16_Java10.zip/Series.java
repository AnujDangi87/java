
/**
 * Write a description of class Series here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Series
{
    int getNext();//Get the next number in the Series
    void reset();//Reset back to initial state
    void setStart(int x);//Start from x
    
}

