public interface MyComparable
{
    //Abstract method that returns some value on basis of implemented class
    int compareTo(int first, int second);
}
