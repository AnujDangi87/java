public class UseC {
    public static void main(String[] args) {
        C c = new C();

        c.method();
    }
}
