public class UseTriangle {
    public static void main(String[] args) {

        int coor[][] = {{0,0}, {1,0}, {0,1}};

        RightAngleTriangle r = new RightAngleTriangle(coor);
        
    }
}
