public class C extends B {
    
    public C()
    {
        System.out.println("this is C class constructor.");
    }

    public void method()
    {
        System.out.println("In class C sum of variable is(a+b) : " +(a+b));
    }
}
