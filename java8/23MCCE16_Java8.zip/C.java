public class C extends B {
    
    public C()
    {
        System.out.println("this is C class constructor.");
    }
}
